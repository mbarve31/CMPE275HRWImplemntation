Cache Client
======================

$ mvn clean package

# How to run the Cache client
$ ./bin/client.sh


